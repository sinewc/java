package sample;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseEvent;
//import javafx.scene.media.Media;
//import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author parn
 */
public class sceneMenuParn implements Initializable {

    @FXML
    private ImageView startButton;
    @FXML
    private ImageView exitButton;
    @FXML
    private ImageView aboutButton;
    @FXML
    private ImageView leftButton0,leftButton1,leftButton2,leftButton3;
    @FXML
    private ImageView rightButton0,rightButton1,rightButton2,rightButton3;
    @FXML
    private ImageView player0,player1,player2,player3;

    private ArrayList<ImageView> leftButtonList=new ArrayList<ImageView>();
    private ArrayList<ImageView> rightButtonList=new ArrayList<ImageView>();
    private ArrayList<ImageView> playerlist=new ArrayList<ImageView>();
    @FXML
    private ImageView speakerOn;
    @FXML
    private ImageView mute;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        setLeftButtonList();
        setRightButtonList();
        playerlist.add(player0);
        playerlist.add(player1);
        playerlist.add(player2);
        playerlist.add(player3);
    }



    @FXML
    private void startButtonAction(MouseEvent event) throws IOException {

        Parent sceneCardParent = FXMLLoader.load(getClass().getResource("scenePlayer1copy.fxml"));
        Scene sceneCardScene = new Scene(sceneCardParent);
        Stage stage = (Stage) startButton.getScene().getWindow();

        stage.setScene(sceneCardScene);
        stage.show();
    }

    @FXML
    private void exitButtonAction(MouseEvent event) {
        Stage stage = (Stage) exitButton.getScene().getWindow();
        stage.close();
    }
    //    String path = "C:\\Users\\parn\\Documents\\NetBeansProjects\\SlaveUpdate\\src\\SlaveGame\\salvegamenut\\src\\audio.parn\\AHNW.mp3";
//    Media op = new Media(new File(path).toURI().toString());
//    MediaPlayer opPlayer = new MediaPlayer(op);
    @FXML

    private void speakerOnAction(MouseEvent event) {
        //opPlayer.play();
    }

    @FXML
    private void muteAction(MouseEvent event) {
        //opPlayer.stop();
    }



    @FXML
    public void upScale(MouseEvent mouseEvent) {
        String Imageviewevent=((ImageView)mouseEvent.getSource()).getId();
        if(Imageviewevent.equals("startButton")) {
           startButton.setScaleX(1.3);
            startButton.setScaleY(1.3);
        }
        else if(Imageviewevent.equals("exitButton")){
            exitButton.setScaleX(1.3);
            exitButton.setScaleY(1.3);
        }
        else if(Imageviewevent.equals("aboutButton")){
            aboutButton.setScaleX(1.3);
            aboutButton.setScaleY(1.3);
        }
    }

    @FXML
    public void defaultScale(MouseEvent mouseEvent) {
        String Imageviewevent=((ImageView)mouseEvent.getSource()).getId();
        if(Imageviewevent.equals("startButton")) {
            startButton.setScaleX(1);
            startButton.setScaleY(1);
        }
        else if(Imageviewevent.equals("exitButton")){
            exitButton.setScaleX(1);
            exitButton.setScaleY(1);
        }
        else if(Imageviewevent.equals("aboutButton")){
            aboutButton.setScaleX(1);
            aboutButton.setScaleY(1);
        }
    }
    public void setLeftButtonList(){
        leftButtonList.add(leftButton0);
        leftButtonList.add(leftButton1);
        leftButtonList.add(leftButton2);
        leftButtonList.add(leftButton3);
    }
    public void setRightButtonList(){
        rightButtonList.add(rightButton0);
        rightButtonList.add(rightButton1);
        rightButtonList.add(rightButton2);
        rightButtonList.add(rightButton3);
    }


    @FXML
    public void upScaleRightButton(MouseEvent mouseEvent) {
        String Imageviewevent=((ImageView)mouseEvent.getSource()).getId();
        int index=getButtton(Imageviewevent);
        rightButtonList.get(index).setScaleX(1.2);
        rightButtonList.get(index).setScaleY(1.2);
    }

    @FXML
    public void defaultScaleRightButton(MouseEvent mouseEvent) {
        String Imageviewevent=((ImageView)mouseEvent.getSource()).getId();
        int index=getButtton(Imageviewevent);
        rightButtonList.get(index).setScaleX(1);
        rightButtonList.get(index).setScaleY(1);
    }
    @FXML
    public void upScaleLeftButton(MouseEvent mouseEvent) {
        String Imageviewevent=((ImageView)mouseEvent.getSource()).getId();
        int index=getButtton(Imageviewevent);
        leftButtonList.get(index).setScaleX(1.2);
        leftButtonList.get(index).setScaleY(1.2);
    }

    @FXML
    public void defaultScaleLeftButton(MouseEvent mouseEvent) {
        String Imageviewevent=((ImageView)mouseEvent.getSource()).getId();
        int index=getButtton(Imageviewevent);
        leftButtonList.get(index).setScaleX(1);
        leftButtonList.get(index).setScaleY(1);
    }

    private int getButtton(String buttonstr){
        for (int i=0;i<4;i++){
            if(buttonstr.equals("leftButton"+i)||buttonstr.equals("rightButton"+i)){
                //System.out.println("getIndexCard = "+i);
                return i;
            }
        }
        return 0;
    }
    @FXML
    private ImageView bg;
    private int change=0;
    private String old=null;
    @FXML
    public void changeImage(MouseEvent mouseEvent) {
        String Imageviewevent=((ImageView)mouseEvent.getSource()).getId();
        int index =getButtton(Imageviewevent);

        if(old!=playerlist.get(index).getId()){
            change=0;
            old=playerlist.get(index).getId();
        }


        if(Imageviewevent.equals("leftButton"+index)){
            //System.out.println("getIndexCard = "+i);
            change--;
        }
        else if(Imageviewevent.equals("rightButton"+index)){
            change++;
        }
        if(change<0){
            change=0;
        }
        else if(change>3){
            change=3;
        }
            if ((index + change) % 4 == 0) {
                Image image = new Image("/pics.parn/Mulan.png");
                playerlist.get(index).setImage(image);
            } else if ((index + change) % 4 == 1) {
                Image image = new Image("/pics.parn/PocaHontas.png");
                playerlist.get(index).setImage(image);
            } else if ((index + change) % 4 == 2) {
                Image image = new Image("/pics.parn/SnowWhite.png");
                playerlist.get(index).setImage(image);
            } else if ((index + change) % 4 == 3) {
                Image image = new Image("/pics.parn/Tiana.png");
                playerlist.get(index).setImage(image);
            }
        System.out.println(change);
    }
}